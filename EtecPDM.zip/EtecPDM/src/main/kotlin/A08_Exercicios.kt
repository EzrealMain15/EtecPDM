fun main()
{
	rAnos(4)
	rPalavra("material")
	rCubo(2)
	mlPraKm(5)
	stringNaoConvertida("converte ai")
	funcaoEx2("material")
	funcaoEx3(2)
	funcaoEx4(5)

	/*1. Escreva uma função que seja capaz de receber a quantidade de anos e tranformar em meses, dias, hras, minutos e segundos. Sída desejada:
    		2 anos equivalem a:
        	24 meses
        	730 dias
        	17520 horas
        	1051200 minutos
        	63072000 segundos*/

fun rAnos(ano: Int)
{
	var meses: Int
	var dias: Int
	var horas: Int
	var minutos: Int
	var segundos: Int
	
    
    
    println("$anos equivalem a: ")
	println("${ano * 12} meses")
	println("${ano * 365} dias")
	println("${ano * 8766} horas")
	println("${ano * 525960} minutos")
	println("${ano * 31536000} segundos")

}

// 2. Escreva uma função capaz de receber um string e retornar a quantidade de carcteres

fun rPalavra(palavra: String)
{
	var tamanho: String

	tamanho = "A palavra $palavra tem o valor de  ${palavra.Length} caracteres"
	println(tamanho)
}

// 3. Escreva uma função capaz de calcular o cubo de um número inteiro (cubo = n*n*n)

fun rCubo(numero: Int)
{
	println("$numero elevado ao cubo é ${numero * numero * numero}")

}


// 4. Escreva uma função capaz de receber uma medida em milhas e converter em km (1 milha = 1.6 km)

fun mlPraKm(milhas: Float)
{
	var conversao: Int = milhas * 1.6

	println(conversão)
}

/* 5. Escreva um programa que seja capaz de receber uma string e fazer a troca todas as letras "a" ou "A" por "x". Observando que:
    a. Não deve existir lógica dentro da função main. Main só deve ser usada como ponto de entrada.
    b. Escrever uma função para a troca de letras e impressão do valor final.
    c. String final deve estar com todas as letras maiúsculas
    Exemplo: Entrada = "Programação em Kotlin" - Saída = "PROGRxMxÇxO EM KOTLIN"
 */

 fun stringNaoConvertida(textoConverter: String)
{
	var textoConvertido: String = textoConverter.uppercase()

	textoConvertido = textoConverter.replace("A", "X")
}

// 6. Sobre as funções criadas nos exercícios 2, 3 e 4, é possível transfomá-las em funções de uma única linha? Se sim, trasforme-as.

}

fun funcaoDoEx2(palavraLinha: String) = {println("A palavra $palavraLinha  tem ${palavra.Length} caracteres")}

fun funcaoDoEx3(numeroLinha: Int) = {println("$numeroLinha elevado ao cubo equivale a ${numeroLinha * numeroLinha * numeroLinha}")}

fun funcaoDoEx4(milhasLinha: Float) = {pintln(milhasLinha * 1.6)}