fun main()
{
    //Aula 04 - Exercicio

    //Ex 1 Declarar variavel para meu nome
    var nome = "Vinicius Gonçalves"

    //Ex 2 - Declarar uma variavel de texto sem valor
    var textoSemValor = ""

    //Ex 3 - Declarar uma variavel de texto imutavel (indicada por val)
    val textoImutavel = "Batata"

    //Ex 4 - Declarar uma variavel imutavel de menor valor para armazenar quanto eu calço
    var meuPe: Byte = 42

    //Ex 5 - Declarar uma variavel capaz de armazenar o PIB do Brasil em 2024 cerca de
    //R$10.900.000.000.000,00
    var pIBDoBrasil: Float = 10900000000000.00f


    //Ex 6 - Declarar uma variavel capaz de armazenar a população do Brasil(Cerca de 212.600.000)
    var populacao: Int = 212600000

    //Ex 7 - Imprima no terminal o valor do PIB per Capta (PIB / população)
    var pIBpErCapta = (pIBDoBrasil / populacao)

    println(pIBpErCapta)

    //Ex 8 - Rode seu programa de forma que não possua erros de compilação ou execução

}
