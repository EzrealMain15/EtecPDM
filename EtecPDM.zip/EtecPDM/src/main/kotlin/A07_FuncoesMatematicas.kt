import kotlin.math.*

// Aula 7: Funções Matem-áticas

fun main() {
    println(max(5, 10))
    println(min(5, 10))
    println(sqrt(49f))

    println(PI)
    println(E)

    println(round(35465.4000009987898789766))
    println(round(PI))
    println(round(E))

    val PI = 3.14159
    print(PI)
}